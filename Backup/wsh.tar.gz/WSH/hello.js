// beginer **MUST**
// 2007/11/19 by ericosur

WScript.Echo("Hello, world");
