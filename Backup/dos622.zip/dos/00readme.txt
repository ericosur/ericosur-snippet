Here are my NT CMD scripts that demonstrate some of the CMD extensions. The NT CMD extensions are poorly documented in general I should say. I have used some commands to just perform some mundane tasks like joining files together, using FOR extensions & some answers to questions posed in the Winntmag forum. Feel free to download these files if you find them useful. Please leave the header of the file as is with the description & other details. This will help you to understand the code & to access my resources again if need be. If there are any bugs in the script file, questions or comments, please send Mail Me!me an email about it.
Thank you very much!


Click Download Code!here to download the CMD scripts.
1) Joins various SQL script files into a single file with different options.
bullet	JOIN1.CMD
2) Joins various SQL script files into a single file with different options.
bullet	JOIN2.CMD
3) Searches the directories specified in the system variable PATH & prints the full path of the filename.
bullet	searchinpath.cmd
4) How to write to registry from CMD scripts?
bullet	3dTextScr.Cmd
5) Joins various SQL script files into a single file.
bullet	JOIN0.CMD
6) One example of a FOR loop extension.
bullet	FOR_EXAMPLE.CMD
7) How to perform arithmetic operations?
bullet	CONVIP.CMD
8) This script shows how to generate filenames with the date/time stamp. I use this to backup my WIN2K profile.
bullet	Backup Profile.Cmd
9) This script shows how to determine the current directory, save it, change directories & restore the original setting.
bullet	DelTemp.Cmd
10) Another example of a FOR loop extension.
bullet	Getting Filenames & Sizes using Batch Commands.Cmd
11) This is the script for MUNGE.EXE. This file contains the strings to be searched for & replaced. I used this as part of my personal HTML project to build this website. This script was used to replace the HTML reserved characters with their codes.
bullet	munge.scr
12) This CMD script is used to format a file for a HTML page & insert them into a database table. I used this to format the content for my web site.
bullet	FmtFile.cmd
13) This script can be used to print the status of all printers on a computer.
bullet	printstat.cmd
14) This CMD script can be used to remove specified number of line(s) from a file(s).
bullet	Remove Lines.Cmd
15) This is a sample script file that is as parameter to "MUNGE.EXE". The "Global Replace.Cmd" script uses this file.
bullet	replace.scr
16) This CMD script can be used to search & replace strings in text files. This shows how to use "MUNGE.EXE" and the NT FOR statements to write simple utilities with less coding.
bullet	Global Replace.Cmd
17) A CMD script to search for a specific file in one or more cabinet files. I have come across several situations that required me to look for a specific DLL file in several CAB files. This small script can make the search easier and less error prone.
bullet	SearchCABs.cmd
18) This CMD script show how to get a specified line from any text file. The filename & line number can be specified as parameters to the script file.
bullet	GetLine.Cmd
19) This CMD script shows how to automate a dial-up process, determine IP address assigned by server, connect to a share on the server, transfer files & disconnect.
bullet	MigrateOE.CMD
20) This script can be used to check if a file was created today. With slight modification, this can be used to check several files.
bullet	ChkToday.cmd